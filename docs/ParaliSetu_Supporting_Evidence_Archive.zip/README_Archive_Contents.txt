================================================================================
PARALISETU — SUPPORTING EVIDENCE & ARCHITECTURAL DOSSIER
SEVA FIRST INNOVATION CHALLENGE 2026
Organized by: Delhi Technological University (DTU) & Govt. of NCT of Delhi
Category: Village & Panchayat Development, Agriculture & Rural Development
Team: Mist | Registration ID: REG-001-OP
Solo Innovator: Rishabh Bansal (Lead Architect & Full-Stack Developer)
Repository: https://github.com/Rishabhbansal005/Parali-Setu-
================================================================================

ARCHIVE STRUCTURE & CONTENTS:

01_Business_Model_Canvas/
  - ParaliSetu_Business_Model_Canvas.pdf : Verified 9-block business model canvas,
    delivering per-tonne gate economics, unit financial waterfall, and multi-tier
    revenue model for smallholders and commercial bio-energy offtakers.

02_System_Architecture_and_Flows/
  - 01_System_Architecture_Diagram.png : 4-tier decoupled system architecture
    (Mobile Client, FastAPI Gateway, PostGIS/OR-Tools Brain, IoT Weighbridge/Escrow).
  - 02_Operational_User_Flow.png : 5-step operational pipeline and sequence flow.
  - 03_Interactive_Architecture_Shot.png : High-resolution system connectivity schematic.

03_Ground_Problem_Evidence/
  - 01_Active_Stubble_Burning_Punjab.jpg : Field documentary photo of post-combine
    paddy residue burning with heavy smoke plumes in rural Punjab.
  - 02_Unmanaged_Straw_Residue_Volume.jpg : 2-acre field inundated with ~2.0 t/acre of
    loose, tangled parali that smallholders cannot manually clear.
  - 03_Seasonal_Smog_and_Low_Visibility.jpg : Sub-100m visibility toxic air pollution
    (AQI 450+) along rural transit corridor during late-autumn harvest.
  - 04_Satellite_Thermal_Fire_Hotspots_Map.jpg : NASA FIRMS / MODIS style Earth
    observation graphic showing concentrated thermal anomalies across Sangrur, Punjab.

04_Working_App_and_Field_Photos/
  - 01_Farmer_Using_ParaliSetu_App_in_Field.jpg : In-field documentary photo of a
    Punjabi farmer operating the trilingual Flutter app via voice intake.
  - 02_Dharamkanta_Weighbridge_Scale_Operation.jpg : Loaded tractor-trolley with parali
    bales on a 60-tonne rural weighbridge with digital scale ticket terminal.
  - 03_Farmer_Mobile_Home_Dashboard.png : Trilingual home screen with weather indicator.
  - 04_Vernacular_Voice_Intake_Screen.png : Speech-to-text NLP interface (pa-IN / hi-IN).
  - 05_Stubble_Yield_and_Value_Calculator.png : PAU-benchmarked stubble recovery math.
  - 06_Weighbridge_IoT_Scale_Terminal.png : One-click gross & tare weight logging UI.
  - 07_Industrial_Buyer_Command_Center.png : Next.js daily biomass quota dashboard.
  - 08_KVK_Satellite_Burn_Audit_Dashboard.png : Sentinel-2 dNBR spectral verification UI.

05_Technical_Specification_and_Agronomics/
  - System_Architecture_and_Database_Specification.txt : Full database schemas, PostGIS
    tables, API endpoint contracts, and security rules (SPEC.md).
  - Agronomic_Ground_Truth_and_Formulas.yaml : Variety-specific stubble yield factors,
    harvest index ratios, and nutrient loss formulas (PAU ground-truth config).

================================================================================
